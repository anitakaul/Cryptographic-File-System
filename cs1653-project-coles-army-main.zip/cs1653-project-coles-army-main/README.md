Please see the [Phase 4 description](desc/phase_4.pdf) for details.

